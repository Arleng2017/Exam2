import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CallApiProvider } from '../../providers/call-api/call-api';

/**
 * Generated class for the BasketPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-basket',
  templateUrl: 'basket.html',
})
export class BasketPage {
  data: any;
  total: number = 0;
  newTotal: number = 0;
  discountTotal: number = 0;
  discount = [];
  dis: number = 0;
  item: number = 0;
  constructor(public navCtrl: NavController, public navParams: NavParams, public callApi: CallApiProvider) {
    this.get();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad BasketPage');
  }

  get() {
    this.callApi.GetAllProductInBasket().subscribe(data => {
      this.data = data;
      console.log(this.data);
      for (let index = 0; index < this.data.length; index++) {
        this.total = this.total + (this.data[index].amount * this.data[index].price);
        this.item = this.data[index].amount;
        while (this.item >= 4) {
          if (this.item >= 4) {
            this.dis += 1;
            this.item = Number(this.item) - 4;
          }
        }
        this.discount.push(this.dis * this.data[index].price)

     
        this.discountTotal=0;
        for (let index = 0; index < this.discount.length; index++) {
          
          this.discountTotal += this.discount[index];
          
        }
        this.newTotal = Number(this.total) - Number(this.discountTotal);

        this.dis = 0;
        this.item = 0;

      }
    });
  }

  test(){
    console.log(this.discount);
    // for (let index = 0; index < this.discount.length; index++) {
    //   this.discountTotal += this.discount[index];
      
    // }
  }
}
