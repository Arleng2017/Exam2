import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { CallApiProvider } from '../../providers/call-api/call-api';
import { BasketPage } from '../basket/basket';
import { FormGroup,FormBuilder } from '@angular/forms';

/**
 * Generated class for the MenuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html',
})
export class MenuPage {
  data: any;
  newProduct: FormGroup;
  
  constructor(public navCtrl: NavController, public navParams: NavParams, public callApi: CallApiProvider, public alertCtrl: AlertController,public fb:FormBuilder) {
    this.get();
    this.newProduct = fb.group({
      'name': null,
      'price': null,
      'pic': null,
      'amount': null,

    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MenuPage');
  }

  get() {
    this.callApi.GetAllProduct().subscribe(data => {
      this.data = data;
      console.log(this.data);
    });
  }
  addToBasket(name:string,price:string,pic:string) {
    console.log(name,price,pic);
    const alert = this.alertCtrl.create({
      title: 'ต้องการเพิ่มสินค้าหรือไม่',
      inputs: [{
        name: 'amount',
        placeholder: 'ใส่จำนวนที่ต้องการ',
        type:'number'
      }
      ],
      buttons: [
        {
          text: 'ยกเลิก'
        },
        {
          text: 'เพิ่ม',
          handler: data => {
            this.newProduct =this.fb.group({
              'name': name,
              'price': price,
              'pic': pic,
              'amount': data.amount,
        
            });
            
            this.callApi.addProductToBasket(this.newProduct.value).subscribe(data=>{
              console.log(this.newProduct);
              console.log("OK");
              
             })

          }
        }
      ]

    });
    alert.present();


  }

  myBasket() {
    this.navCtrl.push(BasketPage);
  }
}
