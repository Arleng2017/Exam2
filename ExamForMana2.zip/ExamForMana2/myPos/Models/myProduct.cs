namespace myPos.Models
{
    public class myProduct

    {
        // public double Tax { get; set; }
        public string Id {get;set;}
        public string Name { get; set; }
        public double  Price{ get; set; }
        public string Pic{ get; set; }
        
        
        
       
    }
}