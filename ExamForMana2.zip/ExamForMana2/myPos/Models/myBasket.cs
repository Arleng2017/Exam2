namespace myPos.Models
{
    public class myBasket

    {
        // public double Tax { get; set; }
        public string Id {get;set;}
        public string Name { get; set; }
        public double  Price{ get; set; }
        public string Pic{ get; set; }
        public int Amount {get;set;}

        
        
        
       
    }
}