﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using myPos.Models;

namespace myPos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BasketController : ControllerBase
    {
        public static List<myBasket> myBasket = new List<myBasket>
        {
            //  new myBasket{
            //     //Id=Guid.NewGuid().ToString(),
            //     Name="สเต๊กปลาดอลลี่",
            //     Price=60,
            //     Pic="https://img.kapook.com/u/annchawan/women4/14808.jpg",
            //     Amount =3

                
          

            // },
            //   new myBasket{
            //     Id=Guid.NewGuid().ToString(),
            //     Name="ข้าว (ไม่มัน) ไก่",
            //     Price=49,
            //     Pic="https://img.kapook.com/u/annchawan/women4/14809.jpg",
            //     Amount=2

            // },


        };
    
        [HttpGet]
        public List<myBasket> GetAllProductInBasket()
        {
            return myBasket;

        }

        [HttpPost]
        public void addItem([FromBody]myBasket newItem){
             myBasket.Add(newItem);
          
        }

        // // [HttpGet("{id}")]
        // // public myPatient GetProduct(String id){
        // //     return  myProduct.Find(it =>it.Id==id);
        // // }
        // [HttpPost]
        // public void CreateProduct([FromBody]myPatient newPatient)
        // {
        //     newPatient.Id = Guid.NewGuid().ToString();
        //     myPatient.Add(newPatient);
        // }


        // [HttpGet("{name}")]
        // public myPatient GetPatient(String name)
        // {
        //     return myPatient.Find(it => it.Name == name);
        // }

        // [HttpPut]
        // public void UpdatePatient([FromBody]myPatient newPatient)
        // {
        //     var oldPatient = myPatient.Find(it => it.Id == newPatient.Id);
        //     myPatient.Remove(oldPatient);
        //     myPatient.Add(newPatient);
        // }
        //  [HttpGet("{que}")]
        // public myPatient GetPatientByQue(int que){
        //     return  myPatient.Find(it =>it.Que==que);
        // }



    }
}
